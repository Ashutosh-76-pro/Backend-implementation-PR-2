# Sprint 1 Execution Summary

## Status
PASS - Sprint 1 data foundation is executable and validated against the supplied source workbook.

## Database
- `companies`: 92
- `profitandloss`: 1,164 loaded from 1,276 source rows
- `balancesheet`: 1,140 loaded from 1,312 source rows
- `cashflow`: 1,056 loaded from 1,187 source rows
- `analysis`: 16 loaded from 20 source rows
- `documents`: 1,456 loaded from 1,586 source rows
- `prosandcons`: 14 loaded from 16 source rows
- `sectors`: 92
- `market_cap`: 552
- `stock_prices`: 5,520
- `financial_ratios`: 1,041
- `peer_groups`: 56

## Quality Gates
- `PRAGMA foreign_key_check`: 0 rows
- Load rejections: 0
- ETL tests: 39 passed
- DQ critical failures: 0
- DQ warnings: 1,249
- Source rows filtered because their ticker is not in the current 92-company master: 439
- Source duplicate composite-key rows deduplicated before load: 255

## DQ Warning Breakdown
- DQ-02 duplicate composite keys: 438
- DQ-03 historical tickers outside the current 92-company master: 433
- DQ-05 OPM cross-check: 234
- DQ-09 stock OHLC ordering: 120
- DQ-11 annual-report URL quality: 11
- DQ-07 year formatting: 9
- DQ-14 required-value nulls in source: 2
- DQ-06 non-positive sales: 1
- DQ-10 cashflow arithmetic mismatch: 1

## Specification Reconciliation
The supplied specification alternates between a 10-table and 12-table description. This implementation keeps all 12 datasets as SQLite tables so both core and supplementary source data remain available for Sprint 2 onward.

from src.etl.loader import load_source_frames
from src.etl.validator import validate_frames

def test_validation_runs_on_source():
    failures=validate_frames(load_source_frames('data/raw/nifty100_source.xlsx'))
    assert isinstance(failures,list)

def test_no_missing_company_master_keys():
    f=load_source_frames('data/raw/nifty100_source.xlsx')
    assert f['companies']['id'].notna().all()

import sqlite3


def test_database_gate():
    con = sqlite3.connect('nifty100.db')
    assert con.execute('SELECT COUNT(*) FROM companies').fetchone()[0] == 92
    assert con.execute('PRAGMA foreign_key_check').fetchall() == []
    con.close()

import pytest
from src.etl.normaliser import normalize_year, normalize_ticker

@pytest.mark.parametrize('value,expected', [
 ('Mar-23','2023-03'),('Mar 23','2023-03'),('Mar-2023','2023-03'),('Mar 2023','2023-03'),('Jan-20','2020-01'),('Feb-19','2019-02'),('Apr-24','2024-04'),('Jun-21','2021-06'),('Jul-22','2022-07'),('Aug-20','2020-08'),('Sep-24','2024-09'),('Oct-18','2018-10'),('Nov-17','2017-11'),('Dec-16','2016-12'),('2024-01-01','2024-01'),('2024-02','2024-02'),('2019','2019'),('2020','2020'),('TTM','TTM'),(None,''),
])
def test_normalize_year(value,expected): assert normalize_year(value)==expected

@pytest.mark.parametrize('value,expected', [
 (' TCS ','TCS'),('tcs','TCS'),('Tcs\n','TCS'),(' ADANI  ENT ','ADANIENT'),('reliance','RELIANCE'),(' HDFCBANK ','HDFCBANK'),('INFY\n','INFY'),('M&M','M&M'),('BAJAJ-AUTO','BAJAJ-AUTO'),('  ITC  ','ITC'),('SBIN','SBIN'),('axisbank','AXISBANK'),('  PNB\n','PNB'),('ONGC','ONGC'),(None,''),
])
def test_normalize_ticker(value,expected): assert normalize_ticker(value)==expected

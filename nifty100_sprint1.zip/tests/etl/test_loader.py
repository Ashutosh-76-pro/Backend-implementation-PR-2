from src.etl.loader import load_source_frames

def test_source_blocks_present():
    frames=load_source_frames('data/raw/nifty100_source.xlsx')
    expected={'companies','profitandloss','balancesheet','cashflow','analysis','documents','prosandcons','sectors','market_cap','stock_prices','financial_ratios','peer_groups'}
    assert expected==set(frames)

def test_core_row_counts():
    f=load_source_frames('data/raw/nifty100_source.xlsx')
    assert len(f['companies'])==92
    assert len(f['profitandloss'])==1276
    assert len(f['balancesheet'])==1312
    assert len(f['cashflow'])==1187
    assert len(f['stock_prices'])==5520

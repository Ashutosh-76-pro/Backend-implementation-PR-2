# Nifty 100 Financial Intelligence Platform - Sprint 1

This repository implements Sprint 1 Data Foundation from the supplied project specification.

## Important source-spec note
The specification contains an internal inconsistency: it says "10 tables" in the Sprint 1 headline, but the dataset catalogue and ETL module explicitly require the 7 core + 5 supplementary datasets, and the listed deliverables include `market_cap` and `peer_groups`. This implementation preserves all 12 source datasets as 12 SQLite tables so no source data is dropped.

## Included
- `nifty100.db` - populated SQLite database
- `output/load_audit.csv` - per-table input/output/rejection counts
- `output/validation_failures.csv` - DQ failures with severity
- `src/etl/loader.py` - merged-workbook block discovery, normalization, SQLite load
- `src/etl/validator.py` - 16 DQ rules
- `src/etl/normaliser.py` - `normalize_year()` and `normalize_ticker()`
- `db/schema.sql` - SQLite schema with PK/FK constraints
- `tests/etl/` - ETL normalization and loader tests
- `notebooks/exploratory_queries.sql` - 10 exploratory SQL queries

## Run
```bash
python -m src.etl.loader --source data/raw/nifty100_source.xlsx --db nifty100.db --output output
pytest -q
```

## Sprint 1 verification targets
- companies = 92
- P&L = 1,276
- Balance Sheet = 1,312
- Cash Flow = 1,187
- stock_prices = 5,520
- `PRAGMA foreign_key_check` = 0 rows

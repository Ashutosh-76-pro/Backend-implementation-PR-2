-- Sprint 1 exploratory checks
SELECT 'companies' AS table_name, COUNT(*) AS rows FROM companies
UNION ALL SELECT 'profitandloss', COUNT(*) FROM profitandloss
UNION ALL SELECT 'balancesheet', COUNT(*) FROM balancesheet
UNION ALL SELECT 'cashflow', COUNT(*) FROM cashflow
UNION ALL SELECT 'stock_prices', COUNT(*) FROM stock_prices;

SELECT MIN(year) AS min_year, MAX(year) AS max_year, COUNT(*) AS rows FROM profitandloss WHERE company_id='TCS';
SELECT company_id, COUNT(*) AS years FROM profitandloss GROUP BY company_id ORDER BY years ASC LIMIT 10;
SELECT company_id, COUNT(*) AS years FROM balancesheet GROUP BY company_id ORDER BY years ASC LIMIT 10;
SELECT company_id, COUNT(*) AS years FROM cashflow GROUP BY company_id ORDER BY years ASC LIMIT 10;
SELECT company_id, COUNT(*) AS months FROM stock_prices GROUP BY company_id HAVING months<>60;
SELECT COUNT(*) AS bad_fk FROM (SELECT p.company_id FROM profitandloss p LEFT JOIN companies c ON c.id=p.company_id WHERE c.id IS NULL);
SELECT company_id, year, sales, opm_percentage FROM profitandloss WHERE sales<=0 OR opm_percentage IS NULL LIMIT 20;
SELECT company_id, year, total_assets, total_liabilities, ABS(total_assets-total_liabilities)/MAX(ABS(total_assets),ABS(total_liabilities),1.0) AS diff_pct FROM balancesheet ORDER BY diff_pct DESC LIMIT 20;
SELECT broad_sector, COUNT(*) AS companies FROM sectors GROUP BY broad_sector ORDER BY companies DESC;

from __future__ import annotations

import argparse
import csv
import re
import sqlite3
import time
from pathlib import Path

import pandas as pd

from .normaliser import normalize_ticker, normalize_year
from .validator import validate_frames, write_failures, validate_database

BLOCKS = {
    "stock_prices": ["id", "company_id", "date", "open_price", "high_price", "low_price", "close_price", "volume", "adjusted_close"],
    "sectors": ["id", "company_id", "broad_sector", "sub_sector", "index_weight_pct", "market_cap_category"],
    "prosandcons": ["id", "company_id", "pros", "cons"],
    "profitandloss": ["id", "company_id", "year", "sales", "expenses", "operating_profit", "opm_percentage", "other_income", "interest", "depreciation", "profit_before_tax", "tax_percentage", "net_profit", "eps", "dividend_payout"],
    "peer_groups": ["id", "peer_group_name", "company_id", "is_benchmark"],
    "market_cap": ["id", "company_id", "year", "market_cap_crore", "enterprise_value_crore", "pe_ratio", "pb_ratio", "ev_ebitda", "dividend_yield_pct"],
    "financial_ratios": ["id", "company_id", "year", "net_profit_margin_pct", "operating_profit_margin_pct", "return_on_equity_pct", "debt_to_equity", "interest_coverage", "asset_turnover", "free_cash_flow_cr", "capex_cr", "earnings_per_share", "book_value_per_share", "dividend_payout_ratio_pct", "total_debt_cr", "cash_from_operations_cr"],
    "documents": ["id", "company_id", "Year", "Annual_Report"],
    "companies": ["id", "company_logo", "company_name", "chart_link", "about_company", "website", "nse_profile", "bse_profile", "face_value", "book_value", "roce_percentage", "roe_percentage"],
    "cashflow": ["id", "company_id", "year", "operating_activity", "investing_activity", "financing_activity", "net_cash_flow"],
    "balancesheet": ["id", "company_id", "year", "equity_capital", "reserves", "borrowings", "other_liabilities", "total_liabilities", "fixed_assets", "cwip", "investments", "other_asset", "total_assets"],
    "analysis": ["id", "company_id", "compounded_sales_growth", "compounded_profit_growth", "stock_price_cagr", "roe"],
}

DB_ORDER = ["companies", "profitandloss", "balancesheet", "cashflow", "analysis", "documents", "prosandcons", "sectors", "market_cap", "stock_prices", "financial_ratios", "peer_groups"]


def discover_header_rows(df: pd.DataFrame) -> dict[str, int]:
    header_rows = {}
    signatures = {tuple(cols): name for name, cols in BLOCKS.items()}
    for i in range(len(df)):
        vals = [str(x).strip() if pd.notna(x) else "" for x in df.iloc[i].tolist()]
        candidate = tuple(vals[: len(vals)])
        for name, cols in BLOCKS.items():
            if vals[: len(cols)] == cols:
                header_rows[name] = i
                break
    missing = set(BLOCKS) - set(header_rows)
    if missing:
        raise ValueError(f"Unable to discover dataset headers: {sorted(missing)}")
    return header_rows


def load_source_frames(path: str | Path) -> dict[str, pd.DataFrame]:
    raw = pd.read_excel(path, sheet_name=0, header=None, dtype=object)
    headers = discover_header_rows(raw)
    ordered = sorted((row, name) for name, row in headers.items())
    frames: dict[str, pd.DataFrame] = {}
    for pos, (start, name) in enumerate(ordered):
        end = ordered[pos + 1][0] if pos + 1 < len(ordered) else len(raw)
        body = raw.iloc[start + 1 : end, : len(BLOCKS[name])].copy()
        # Drop banner/blank rows; keep rows with at least one value.
        body = body.dropna(how="all")
        body.columns = BLOCKS[name]
        # Stop at any later banner or accidental text row.
        if "Bluestock Fintech" in body.iloc[:, 0].astype(str).to_string():
            body = body[~body.iloc[:, 0].astype(str).str.contains("Bluestock Fintech", na=False)]
        if name != "companies" and "company_id" in body.columns:
            body["company_id"] = body["company_id"].map(normalize_ticker)
        if "year" in body.columns:
            body["year"] = body["year"].map(normalize_year)
        if "Year" in body.columns:
            body["year"] = body.pop("Year").map(lambda x: normalize_year(x) if str(x).strip() != "" else "")
        if "Annual_Report" in body.columns:
            body["annual_report"] = body.pop("Annual_Report")
        if name == "companies":
            body["id"] = body["id"].map(normalize_ticker)
        if name == "sectors" and "id" in body.columns:
            body = body.drop(columns=["id"])
        # Drop repeated header rows if present.
        body = body[body.iloc[:, 0].astype(str).str.lower().ne("id")]
        frames[name] = body.reset_index(drop=True)
    return frames


def _coerce(frame: pd.DataFrame) -> pd.DataFrame:
    df = frame.copy()
    text_cols = {"id", "company_id", "company_logo", "company_name", "chart_link", "about_company", "website", "nse_profile", "bse_profile", "peer_group_name", "broad_sector", "sub_sector", "market_cap_category", "pros", "cons", "compounded_sales_growth", "compounded_profit_growth", "stock_price_cagr", "roe", "annual_report", "year", "date"}
    for c in df.columns:
        if c in text_cols:
            df[c] = df[c].apply(lambda x: str(x).strip() if pd.notna(x) else None)
        else:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    if "is_benchmark" in df.columns:
        df["is_benchmark"] = df["is_benchmark"].fillna(0).astype(int)
    return df


def write_audit(audit: list[dict], out_path: str | Path):
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    fields = ["table", "rows_in", "rows_out", "rejected", "filtered_out", "deduped", "timestamp", "runtime_s"]
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(audit)


def build_database(frames: dict[str, pd.DataFrame], db_path: str | Path, schema_path: str | Path, output_dir: str | Path):
    db_path = Path(db_path); db_path.parent.mkdir(parents=True, exist_ok=True)
    output_dir = Path(output_dir); output_dir.mkdir(parents=True, exist_ok=True)
    if db_path.exists(): db_path.unlink()
    con = sqlite3.connect(db_path)
    con.execute("PRAGMA foreign_keys = ON")
    con.executescript(Path(schema_path).read_text(encoding="utf-8"))
    audit=[]
    failures=validate_frames(frames)
    write_failures(failures, output_dir / "validation_failures.csv")
    for name in DB_ORDER:
        start=time.perf_counter(); df=_coerce(frames[name]); rows_in=len(df); deduped=0; filtered_out=0
        # Critical DQ violations are not silently written to the database.
        bad_fk = [c for c in ["company_id"] if c in df.columns]
        if name != "companies" and bad_fk:
            valid_ids=set(frames["companies"]["id"].dropna())
            before_filter=len(df); df=df[df.company_id.isin(valid_ids)].copy(); filtered_out=before_filter-len(df)
        # Resolve source duplicate composite keys before SQLite insert. This is deduplication, not a rejected-row failure.
        if name in {"profitandloss","balancesheet","cashflow","financial_ratios","market_cap","documents","stock_prices"}:
            key = ["company_id","date"] if name=="stock_prices" else ["company_id","year"]
            before=len(df); df=df.drop_duplicates(key, keep="last").copy(); deduped=before-len(df)
        # Insert with explicit column order and ignore duplicates only for noncritical text tables.
        cols=list(df.columns)
        q=','.join('?' for _ in cols)
        sql=f"INSERT INTO {name} ({','.join(cols)}) VALUES ({q})"
        rows=[]
        for row in df.itertuples(index=False, name=None):
            vals=[]
            for v in row:
                if pd.isna(v): vals.append(None)
                else: vals.append(v.item() if hasattr(v,'item') else v)
            rows.append(tuple(vals))
        rejected=0
        try:
            con.executemany(sql, rows)
        except sqlite3.IntegrityError as exc:
            con.rollback()
            # Retry row-by-row so bad rows are auditable.
            inserted=0
            for row in rows:
                try:
                    con.execute(sql,row); inserted+=1
                except sqlite3.IntegrityError:
                    rejected+=1
            con.commit()
        else:
            con.commit(); inserted=len(rows)
        audit.append({"table":name,"rows_in":rows_in,"rows_out":inserted,"rejected":rejected,"filtered_out":filtered_out,"deduped":deduped,"timestamp":pd.Timestamp.utcnow().isoformat(),"runtime_s":round(time.perf_counter()-start,4)})
    con.close()
    audit_path=output_dir/"load_audit.csv"; write_audit(audit,audit_path)
    db_fk=validate_database(str(db_path))
    if db_fk:
        all_failures=[]
        with open(output_dir/"validation_failures.csv", encoding="utf-8") as f:
            all_failures=list(csv.DictReader(f))
        all_failures.extend(db_fk)
        write_failures(all_failures, output_dir/"validation_failures.csv")
    return audit, failures, db_fk


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--source', required=True); ap.add_argument('--db', default='nifty100.db'); ap.add_argument('--output', default='output')
    a=ap.parse_args(); frames=load_source_frames(a.source); audit, failures, db_fk=build_database(frames,a.db,'db/schema.sql',a.output)
    print('Loaded tables:')
    for row in audit: print(row['table'], row['rows_in'], '->', row['rows_out'], 'rejected=', row['rejected'])
    print('Pre-load DQ failures:',len(failures),'DB FK failures:',len(db_fk))

if __name__=='__main__': main()

from __future__ import annotations

import math
import re
from datetime import datetime

_MONTHS = {
    "jan": "01", "feb": "02", "mar": "03", "apr": "04",
    "may": "05", "jun": "06", "jul": "07", "aug": "08",
    "sep": "09", "oct": "10", "nov": "11", "dec": "12",
}


def normalize_ticker(value: object) -> str:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return ""
    text = str(value).replace("\n", " ").strip().upper()
    return re.sub(r"\s+", "", text)


def normalize_year(value: object) -> str:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return ""
    if isinstance(value, datetime):
        return value.strftime("%Y-%m")
    text = str(value).strip()
    if not text:
        return ""
    if re.fullmatch(r"\d{4}-\d{2}(-\d{2})?", text):
        return text[:7]
    if re.fullmatch(r"\d{4}", text):
        return text
    m = re.fullmatch(r"([A-Za-z]{3})[- ]?(\d{2,4})", text)
    if m:
        month = _MONTHS[m.group(1).lower()]
        year = int(m.group(2))
        if year < 100:
            year += 2000 if year < 50 else 1900
        return f"{year:04d}-{month}"
    if re.fullmatch(r"\d{1,2}/\d{1,2}/\d{4}", text):
        dt = datetime.strptime(text, "%d/%m/%Y")
        return dt.strftime("%Y-%m")
    if text.upper() == "TTM":
        return "TTM"
    return text

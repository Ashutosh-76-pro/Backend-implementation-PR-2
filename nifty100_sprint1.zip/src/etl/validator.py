from __future__ import annotations

import argparse
import csv
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from .normaliser import normalize_ticker, normalize_year

CRITICAL = "CRITICAL"
WARNING = "WARNING"


def _failure(rule, company_id, year, field, issue, severity):
    return {
        "rule": rule,
        "company_id": company_id,
        "year": year,
        "field": field,
        "issue": issue,
        "severity": severity,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def validate_frames(frames: dict[str, pd.DataFrame]) -> list[dict]:
    failures: list[dict] = []
    companies = frames["companies"]
    company_ids = set(companies["id"].dropna().map(normalize_ticker))

    # DQ-01 / DQ-12: company key uniqueness and coverage
    dup = companies["id"].map(normalize_ticker).duplicated(keep=False)
    for idx in companies.index[dup]:
        failures.append(_failure("DQ-01", normalize_ticker(companies.at[idx, "id"]), "", "id", "Duplicate company primary key", CRITICAL))
    if len(company_ids) != 92:
        failures.append(_failure("DQ-12", "", "", "companies", f"Expected 92 companies, found {len(company_ids)}", CRITICAL))

    timeseries = ["profitandloss", "balancesheet", "cashflow", "financial_ratios", "market_cap", "documents", "stock_prices"]
    for name in timeseries:
        df = frames[name]
        if "company_id" in df.columns:
            df["company_id"] = df["company_id"].map(normalize_ticker)
            for idx, row in df.loc[~df["company_id"].isin(company_ids)].iterrows():
                failures.append(_failure("DQ-03", row.get("company_id", ""), row.get("year", row.get("date", "")), "company_id", "Foreign key not present in current 92-company master; row will be filtered", WARNING))
        if "year" in df.columns:
            df["year"] = df["year"].map(normalize_year)

    # DQ-02 composite PK uniqueness.
    for name in ["profitandloss", "balancesheet", "cashflow", "financial_ratios", "market_cap", "documents"]:
        df = frames[name]
        if {"company_id", "year"}.issubset(df.columns):
            dup = df.duplicated(["company_id", "year"], keep=False)
            for idx in df.index[dup]:
                failures.append(_failure("DQ-02", df.at[idx, "company_id"], df.at[idx, "year"], "company_id,year", "Duplicate composite key; loader will deduplicate", WARNING))
    dup = frames["stock_prices"].duplicated(["company_id", "date"], keep=False)
    for idx in frames["stock_prices"].index[dup]:
        r = frames["stock_prices"].loc[idx]
        failures.append(_failure("DQ-02", r.company_id, r.date, "company_id,date", "Duplicate stock-price key; loader will deduplicate", WARNING))

    # DQ-04 BS balance, DQ-05 OPM, DQ-06 positive sales.
    bs = frames["balancesheet"]
    for _, r in bs.iterrows():
        denom = max(abs(float(r.total_assets or 0)), abs(float(r.total_liabilities or 0)), 1.0)
        diff = abs(float(r.total_assets or 0) - float(r.total_liabilities or 0)) / denom
        if diff > 0.01:
            failures.append(_failure("DQ-04", r.company_id, r.year, "total_assets/total_liabilities", f"Balance sheet differs by {diff:.2%}", WARNING))

    pl = frames["profitandloss"]
    for _, r in pl.iterrows():
        sales = float(r.sales or 0)
        if sales <= 0:
            failures.append(_failure("DQ-06", r.company_id, r.year, "sales", "Sales must be > 0", WARNING))
        if sales:
            calc = float(r.operating_profit or 0) / sales * 100
            if abs(calc - float(r.opm_percentage or 0)) > max(1.0, abs(float(r.opm_percentage or 0)) * 0.01):
                failures.append(_failure("DQ-05", r.company_id, r.year, "opm_percentage", f"Source OPM {r.opm_percentage} vs calculated {calc:.2f}", WARNING))

    # DQ-07 year format, DQ-08 ticker format.
    for name, df in frames.items():
        if "company_id" in df.columns:
            bad = df["company_id"].astype(str).str.strip().ne(df["company_id"].map(normalize_ticker))
            for idx in df.index[bad]:
                failures.append(_failure("DQ-08", df.at[idx, "company_id"], df.at[idx, "year"] if "year" in df.columns else "", "company_id", "Ticker is not normalized", CRITICAL))
        if "year" in df.columns:
            bad = ~df["year"].astype(str).str.match(r"^(\d{4}(-\d{2})?|TTM)$", na=False)
            for idx in df.index[bad]:
                failures.append(_failure("DQ-07", df.at[idx, "company_id"] if "company_id" in df.columns else "", df.at[idx, "year"], "year", "Unsupported year format", WARNING))

    # DQ-09 stock OHLC, DQ-10 cashflow arithmetic, DQ-11 documents duplicates/URLs, DQ-13 ratio ranges,
    # DQ-14 required values, DQ-15 sector coverage, DQ-16 source completeness.
    prices = frames["stock_prices"]
    for _, r in prices.iterrows():
        if not (float(r.low_price) <= min(float(r.open_price), float(r.close_price), float(r.high_price)) and float(r.high_price) >= max(float(r.open_price), float(r.close_price))):
            failures.append(_failure("DQ-09", r.company_id, r.date, "OHLC", "OHLC ordering is invalid", WARNING))

    cf = frames["cashflow"]
    for _, r in cf.iterrows():
        calc = float(r.operating_activity) + float(r.investing_activity) + float(r.financing_activity)
        if abs(calc - float(r.net_cash_flow)) > 10:
            failures.append(_failure("DQ-10", r.company_id, r.year, "net_cash_flow", f"Expected {calc:.2f}, source {r.net_cash_flow}", WARNING))

    docs = frames["documents"]
    for _, r in docs.iterrows():
        url = str(r.annual_report).strip()
        if url and url.lower() not in {"null", "nan"} and not url.startswith("http"):
            failures.append(_failure("DQ-11", r.company_id, r.year, "annual_report", "Annual report value is not a URL", WARNING))

    ratios = frames["financial_ratios"]
    for _, r in ratios.iterrows():
        if r.debt_to_equity is not None and pd.notna(r.debt_to_equity) and float(r.debt_to_equity) < 0:
            failures.append(_failure("DQ-13", r.company_id, r.year, "debt_to_equity", "D/E cannot be negative", WARNING))

    required = [("companies", "id"), ("profitandloss", "sales"), ("balancesheet", "total_assets"), ("cashflow", "net_cash_flow")]
    for name, col in required:
        nulls = frames[name][col].isna()
        for idx in frames[name].index[nulls]:
            failures.append(_failure("DQ-14", frames[name].at[idx, "company_id"] if "company_id" in frames[name].columns else frames[name].at[idx, "id"], "", col, "Required value is null", WARNING))

    sectors = frames["sectors"]
    if set(sectors["company_id"].map(normalize_ticker)) != company_ids:
        failures.append(_failure("DQ-15", "", "", "sectors", "Sector coverage does not equal company universe", CRITICAL))

    expected = {"companies": 92, "profitandloss": 1276, "balancesheet": 1312, "cashflow": 1187, "stock_prices": 5520}
    for name, target in expected.items():
        actual = len(frames[name])
        if actual < target:
            failures.append(_failure("DQ-16", "", "", name, f"Expected at least {target} source rows, found {actual}", CRITICAL))
    return failures


def write_failures(failures: list[dict], path: str | os.PathLike) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fields = ["rule", "company_id", "year", "field", "issue", "severity", "timestamp"]
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(failures)


def validate_database(db_path: str) -> list[dict]:
    failures = []
    con = sqlite3.connect(db_path)
    con.execute("PRAGMA foreign_keys=ON")
    fk = con.execute("PRAGMA foreign_key_check").fetchall()
    for row in fk:
        failures.append(_failure("DQ-03", "", "", "foreign_key_check", str(row), CRITICAL))
    con.close()
    return failures


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", default="data/raw/nifty100_source.xlsx")
    parser.add_argument("--output", default="output")
    args = parser.parse_args()
    from .loader import load_source_frames
    frames = load_source_frames(args.source)
    failures = validate_frames(frames)
    write_failures(failures, Path(args.output) / "validation_failures.csv")
    print(f"Validation failures: {len(failures)}")

if __name__ == "__main__":
    main()
